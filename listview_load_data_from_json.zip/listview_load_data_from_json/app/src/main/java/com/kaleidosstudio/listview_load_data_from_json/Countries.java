package com.kaleidosstudio.listview_load_data_from_json;

public class Countries {
	String PhoneNo;
	String Name;
	String Items;
	String Location;
}
